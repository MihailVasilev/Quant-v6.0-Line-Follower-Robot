/**
 * Project: High-Speed Line Follower for InfoMatrix 2026
 * Team: RoboCode (Varna, Bulgaria)
 * Robot: Quant (Custom Build)
 * Hardware: Arduino Nano, L298P Driver, 6 Infrared Sensors (KY-033)
 */

// --- Speed and Balance Settings ---
float balanceCoefficient = 0.78; // Balancing left/right motor power
int baseSpeed = 65;              // Baseline speed for motors (0-255)

// --- Sensor Configuration ---
const int sensorPins[] = {A0, A1, A2, A3, A4, A5}; 
int threshold = 600;             // Calculated automatically during setup

// --- L298P Driver Pinout ---
const int ENA = 5;  // PWM Speed Control Left
const int IN1 = 6;  // Direction Left
const int IN2 = 7;  // Direction Left
const int IN3 = 8;  // Direction Right
const int IN4 = 9;  // Direction Right
const int ENB = 10; // PWM Speed Control Right

// --- PD Controller Parameters ---
float Kp = 3.0;     // Proportional Gain: Sensitivity to error
float Kd = 15.0;    // Derivative Gain: Dampens oscillations (D-term)
int lastError = 0;

void setup() {
  // Initialize motor driver pins
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT); pinMode(ENB, OUTPUT);
  
  Serial.begin(9600);

  // --- Static Calibration Routine ---
  // Calibrates by averaging black line (center) and white surface (sides)
  long sumBlack = 0;
  long sumWhite = 0;

  for (int i = 0; i < 100; i++) {
    sumBlack += (analogRead(A2) + analogRead(A3)) / 2; // Central sensors on black line
    sumWhite += (analogRead(A0) + analogRead(A5)) / 2; // Side sensors on white surface
    delay(5);
  }

  int avgBlack = sumBlack / 100;
  int avgWhite = sumWhite / 100;

  threshold = (avgBlack + avgWhite) / 2; // Midpoint threshold
}

void loop() {
  // 1. Get current position relative to the line
  int position = getLinePosition();
  
  // 2. PD Algorithm Calculation
  int error = position;
  int derivative = error - lastError;
  float adjustment = (Kp * error) + (Kd * derivative);
  lastError = error;

  // 3. Calculate target speeds for each motor
  int currentBaseL = baseSpeed;
  int currentBaseR = baseSpeed * balanceCoefficient;

  // Apply PD adjustment (Inversion logic for correct steering)
  int leftMotorSpeed = currentBaseL - adjustment; 
  int rightMotorSpeed = currentBaseR + adjustment; 

  // 4. Execution
  move(leftMotorSpeed, rightMotorSpeed);
}

/**
 * Calculates weighted error based on 6 sensors.
 * Returns value from negative (left) to positive (right).
 */
int getLinePosition() {
  long average = 0;
  int sum = 0;
  int weights[] = {-15, -10, -5, 5, 10, 15}; // Weights for sensor positioning

  for (int i = 0; i < 6; i++) {
    int val = analogRead(sensorPins[i]);
    if (val > threshold) { // Sensor is over the black line
      average += (long)weights[i];
      sum++;
    }
  }

  // Safety: If no sensors detect the line, return last known error
  if (sum == 0) {
    if (lastError < 0) return -20;
    if (lastError > 0) return 20;
    return 0;
  }

  return (average * 10) / sum; // Scaled output for better PD resolution
}

/**
 * Motor control function with speed constraints.
 */
void move(int speedL, int speedR) {
  // Constrain speeds to valid PWM range
  speedL = constrain(speedL, 0, 255);
  speedR = constrain(speedR, 0, 255);
  
  analogWrite(ENA, speedL);
  analogWrite(ENB, speedR);

  // Standard forward direction for L298P
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, HIGH);
  digitalWrite(IN4, LOW);
}
